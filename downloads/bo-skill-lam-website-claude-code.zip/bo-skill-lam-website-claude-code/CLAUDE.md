# CLAUDE.md mẫu cho dự án website

> Chép file này vào thư mục gốc dự án, sửa các dòng có [ ], xoá dòng này.

## Dự án
- Website: [tên] — [mô tả 1 câu: cho ai, để làm gì]
- Tên miền: [https://tenmien.com]
- Kỹ thuật: HTML/CSS/JS thuần, không framework, đưa lên GitHub Pages từ nhánh `main`.
- Brief đầy đủ: xem `BRIEF.md`.

## Thương hiệu
- Màu: chính [#xxxxxx], phụ [#xxxxxx], nền [#xxxxxx], chữ [#xxxxxx]
- Font: tiêu đề [tên font], nội dung [tên font] (Google Fonts)
- Giọng văn: [thân thiện, xưng "mình" – "bạn" / trang trọng, xưng "chúng tôi" – "quý khách"]
- Logo: `images/logo.png` — luôn dùng file này, không gõ chữ thay logo.

## Quy tắc làm việc
- Điện thoại trước: kiểm tra 375px, 768px, 1280px trước khi báo xong.
- Không bịa thông tin thật (giá, số điện thoại, địa chỉ, số liệu). Thiếu thì ghi [CẦN ĐIỀN].
- Sửa theo góp ý thì chỉ sửa đúng chỗ được nhắc.
- Ảnh mới: nén dưới ~300KB, có alt mô tả.
- Trang mới: copy khối `<head>` (meta, Open Graph, favicon) từ trang chủ rồi sửa lại cho trang đó, và thêm vào `sitemap.xml`.
- Trước mỗi lần push: chạy `/check-site`.
