---
name: check-site
description: Kiểm tra website trước khi đưa lên mạng hoặc sau mỗi lần sửa: chụp màn hình ở điện thoại, tablet, máy tính bằng Playwright, tìm tràn ngang, chữ chồng, ảnh vỡ, link hỏng, lỗi JavaScript, rồi sửa và kiểm tra lại. Dùng khi người dùng nói "kiểm tra", "xem thử", "test", "có lỗi không", "trước khi đăng".
---

# Kiểm tra website

## Chuẩn bị

- Chạy server tĩnh ở thư mục gốc: `python3 -m http.server 8000` (chạy nền). Windows: thử `python -m http.server 8000`, không có Python thì dùng `npx serve -l 8000`.
- Kiểm tra Node.js trước: `node --version`. Nếu chưa có, **dừng lại** và hướng dẫn người dùng mở một cửa sổ Terminal mới (không phải trong Claude Code), tải bản LTS tại https://nodejs.org (hoặc `brew install node` trên Mac, `winget install OpenJS.NodeJS.LTS` trên Windows), rồi mở lại Terminal.
- Dùng Playwright. Nếu chưa có: `npm init -y && npm i -D playwright && npx playwright install chromium`. Thêm `node_modules/` vào `.gitignore`.

## Kiểm tra từng trang

Với mỗi trang HTML, ở 3 kích thước **375×800, 768×1024, 1280×800**:

1. Chụp màn hình toàn trang, lưu vào `screenshots/<trang>-<rộng>.png`, rồi **xem từng ảnh**.
2. Tràn ngang: `document.documentElement.scrollWidth > window.innerWidth` là lỗi.
3. Ảnh vỡ: mọi `img` phải có `naturalWidth > 0`.
4. Lỗi JavaScript: bắt `pageerror` và `console` mức error.
5. Link nội bộ phải trỏ tới file có thật; `href="#id"` phải có phần tử mang id đó. Nếu website chưa có tên miền riêng, báo lỗi mọi `href`/`src` bắt đầu bằng `/` (sẽ hỏng trên `<tên>.github.io/<repo>/`).
6. Nhìn bằng mắt: chữ chồng nhau, chữ quá nhỏ trên điện thoại (dưới ~14px), nút quá sát nhau, độ tương phản chữ/nền kém.

## Báo cáo

- Liệt kê lỗi theo bảng: trang · kích thước · lỗi · cách sửa.
- Sửa từng lỗi, rồi **chạy lại toàn bộ kiểm tra** và báo kết quả lần hai.
- Không xoá ảnh chụp màn hình trong `screenshots/` nhưng thêm thư mục đó vào `.gitignore`.
- Nhắc người dùng: sau khi website lên mạng, tự mở trên điện thoại thật và bấm thử mọi nút liên hệ.
