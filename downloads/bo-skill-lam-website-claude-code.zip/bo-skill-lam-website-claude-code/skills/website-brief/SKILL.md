---
name: website-brief
description: Phỏng vấn người dùng từng câu một để làm rõ website cần làm (cho ai, mục tiêu, các mục, phong cách, nội dung có sẵn), rồi viết BRIEF.md để duyệt trước khi code. Dùng khi người dùng muốn bắt đầu một website, landing page hay portfolio mới, hoặc nói "làm web", "bắt đầu dự án web", "viết brief".
---

# Viết brief website

Mục tiêu: trước khi viết một dòng code, có một file `BRIEF.md` mà người dùng đã đọc và đồng ý. Người dùng thường không rành kỹ thuật, nên hỏi bằng lời thường và đưa ví dụ.

## Cách làm

1. Nếu người dùng đã kể sẵn vài thông tin, ghi nhận và chỉ hỏi phần còn thiếu.
2. Hỏi **từng câu một**, đánh số "Câu x/6", mỗi câu kèm 2–3 ví dụ trả lời:
   1. Ai sẽ vào website, và điều quan trọng nhất bạn muốn họ làm là gì? (nhắn Zalo, gọi điện, đặt lịch, mua hàng, để lại email)
   2. Website cần những trang hoặc mục nào?
   3. Thông tin liên hệ thật: số điện thoại, Zalo, email, địa chỉ, giờ mở cửa.
   4. Phong cách: màu chủ đạo, cảm giác (sang, trẻ trung, tối giản), 1–3 website tham khảo.
   5. Nội dung và hình ảnh đã có: logo, ảnh sản phẩm, bài giới thiệu. Ảnh nên chép vào thư mục `images/`.
   6. Tiếng Việt, tiếng Anh hay song ngữ? Đã có tên miền chưa?
3. Không tự bịa thông tin thật (giá, số điện thoại, địa chỉ, số liệu). Chỗ chưa có thì ghi `[CẦN ĐIỀN]`.
4. Viết `BRIEF.md` theo mẫu dưới, cho người dùng xem và hỏi có cần sửa gì không. **Chưa viết code** cho tới khi người dùng đồng ý.

## Mẫu BRIEF.md

```markdown
# Brief: <tên website>

## Người xem và mục tiêu
- Người xem chính:
- Hành động mong muốn (1 hành động chính):

## Cấu trúc
- Trang / mục:

## Liên hệ
- Zalo / điện thoại / email / địa chỉ / giờ mở cửa:

## Phong cách
- Màu chủ đạo, cảm giác, website tham khảo:

## Nội dung có sẵn
- Logo, ảnh (đường dẫn trong images/), bài viết:

## Kỹ thuật
- Ngôn ngữ:
- Tên miền:
- Nền tảng: HTML/CSS/JS tĩnh, đưa lên GitHub Pages

## Còn thiếu
- [CẦN ĐIỀN] ...
```
