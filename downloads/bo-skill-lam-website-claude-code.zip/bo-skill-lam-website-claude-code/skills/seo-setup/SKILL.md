---
name: seo-setup
description: Làm SEO cơ bản cho website tĩnh: title và meta description từng trang, Open Graph để chia sẻ Facebook/Zalo có ảnh, dữ liệu có cấu trúc JSON-LD, favicon, sitemap.xml, robots.txt, alt ảnh, canonical. Dùng khi người dùng nhắc SEO, Google, chia sẻ Facebook không hiện ảnh, sitemap, Search Console.
---

# SEO cơ bản

Hỏi trước nếu chưa biết: **tên miền** (ví dụ `https://tenmien.com`) và **1–3 từ khoá chính** khách hay tìm.

## Việc cần làm cho mỗi trang

1. `<title>` riêng, dưới ~60 ký tự, có từ khoá chính và tên thương hiệu.
2. `<meta name="description">` 140–160 ký tự, viết như lời mời bấm vào.
3. `<link rel="canonical">` bằng URL tuyệt đối của trang.
4. Open Graph và Twitter: `og:title`, `og:description`, `og:url`, `og:type`, `og:image` (URL **tuyệt đối**, ảnh 1200×630, dưới ~300KB), `twitter:card=summary_large_image`. Nếu chưa có ảnh chia sẻ, tạo một ảnh 1200×630 đơn giản từ màu và logo thương hiệu.
5. Đúng một `h1`, các tiêu đề `h2`/`h3` theo thứ tự, mọi ảnh có `alt`.

## Việc cần làm cho cả website

- JSON-LD phù hợp: `Person` cho portfolio, `LocalBusiness` cho cửa hàng (tên, địa chỉ, điện thoại, giờ mở cửa thật), `Organization` cho công ty. Chỉ điền thông tin thật.
- Bộ favicon: `favicon.ico`, `favicon-32.png`, `apple-touch-icon.png` (180×180), khai báo trong `<head>` mọi trang.
- `sitemap.xml` liệt kê mọi trang với URL tuyệt đối, và `robots.txt` trỏ tới sitemap.
- Trang có `lang` đúng (`vi` hoặc `en`).
- Tuỳ chọn: Google Analytics 4. Hỏi mã đo lường dạng `G-XXXXXXXXXX`, chèn đoạn mã gtag vào `<head>` mọi trang (bản `async`), và chỉ người dùng xem báo cáo Thời gian thực để kiểm tra.

## Kiểm tra

- `JSON.parse` từng khối JSON-LD để chắc hợp lệ.
- Mọi file ảnh og:image tồn tại đúng đường dẫn.
- Nhắc người dùng: sau khi website lên mạng, thêm vào Google Search Console và gửi `sitemap.xml`.
