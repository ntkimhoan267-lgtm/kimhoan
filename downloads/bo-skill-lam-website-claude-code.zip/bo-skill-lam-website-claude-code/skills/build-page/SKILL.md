---
name: build-page
description: Dựng hoặc sửa một trang của website tĩnh (HTML/CSS/JS thuần) theo BRIEF.md và CLAUDE.md, ưu tiên điện thoại, nội dung thật, ảnh nén gọn, dễ truy cập. Dùng khi người dùng nói "dựng trang", "làm trang chủ", "thêm mục", "sửa giao diện", "đổi màu", hoặc gửi ảnh chụp màn hình kèm góp ý.
---

# Dựng và sửa trang

## Trước khi làm

- Đọc `BRIEF.md` và `CLAUDE.md` nếu có. Làm đúng màu, font, giọng văn đã ghi ở đó.
- Nếu là sửa theo góp ý: **chỉ sửa đúng chỗ được nhắc**, giữ nguyên phần còn lại.
- Thay đổi lớn (thêm trang mới, đổi bố cục toàn trang): trình bày kế hoạch ngắn và chờ đồng ý trước.

## Quy tắc kỹ thuật

- HTML/CSS/JS thuần, không framework, không bước build. Cấu trúc gợi ý: `index.html`, `css/style.css`, `js/main.js`, `images/`.
- Thiết kế cho điện thoại trước (375px), rồi mở rộng cho 768px và 1280px. Không để trang tràn ngang.
- **Đường dẫn tương đối** cho mọi link, ảnh, CSS, JS (`images/logo.png`, `css/style.css`, không có `/` ở đầu). Website trên GitHub Pages không có tên miền riêng chạy ở `https://<tên>.github.io/<repo>/`, đường dẫn bắt đầu bằng `/` sẽ bị lỗi 404.
- Màu và font khai báo một lần bằng biến CSS trong `:root`. Font lấy từ Google Fonts, luôn có font dự phòng.
- Dùng thẻ ngữ nghĩa: `header`, `nav`, `main`, `section`, `footer`. Mỗi trang đúng một `h1`.
- Mọi ảnh có `alt` mô tả, có `width`/`height`, ảnh dưới màn hình đầu dùng `loading="lazy"`. Ảnh nặng hơn ~300KB thì nén hoặc thu nhỏ (rộng tối đa ~1600px).
- Nút và link đủ lớn để bấm bằng ngón tay (tối thiểu ~44px), có trạng thái focus nhìn thấy được.
- Nút liên hệ (Zalo, gọi điện) dùng link thật: `https://zalo.me/<số>`, `tel:<số>`.
- Không dùng lorem ipsum. Thiếu thông tin thì để `[CẦN ĐIỀN]` và báo người dùng.
- **Form liên hệ:** GitHub Pages là hosting tĩnh, form tự viết không gửi được. Dùng nút Zalo/Messenger/gọi điện, link Google Forms, hoặc dịch vụ nhận form (Formspree...). Không bao giờ để lại form không gửi được.

## Lưu lịch sử

- Nếu thư mục chưa có git: `git init`, tạo `.gitignore` (`node_modules/`, `screenshots/`, `.DS_Store`), commit bản đầu.
- Sau mỗi phần người dùng đã duyệt: commit với lời nhắn ngắn mô tả thay đổi.

## Khi xong

- Nói người dùng cách xem: mở file `index.html` bằng trình duyệt (nhấp đúp), hoặc chạy `python3 -m http.server` rồi vào `http://localhost:8000`.
- Tóm tắt đã làm gì, còn thiếu gì, và gợi ý bước tiếp theo (thường là `/check-site`).
