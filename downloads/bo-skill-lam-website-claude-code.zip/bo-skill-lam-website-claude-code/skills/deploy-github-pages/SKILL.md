---
name: deploy-github-pages
description: Đưa website tĩnh lên mạng miễn phí bằng GitHub Pages, gắn tên miền riêng (file CNAME + bản ghi DNS), bật HTTPS, và hướng dẫn xác minh Google Search Console. Dùng khi người dùng nói "đưa lên mạng", "deploy", "publish", "gắn tên miền", "GitHub Pages", "Search Console".
---

# Đưa lên GitHub Pages

Người dùng thường mới dùng GitHub lần đầu: giải thích ngắn từng bước, chờ họ làm xong bước cần thao tác trên web rồi mới đi tiếp.

## 1. Git

- Nếu chưa có git: `git init`, tạo `.gitignore` (bỏ `node_modules/`, `screenshots/`, `.DS_Store`), commit đầu tiên.
- Nếu đã có: kiểm tra `git status` sạch, commit nốt thay đổi còn lại.
- Rà thư mục: không được có giấy tờ, file khách hàng, mật khẩu, mã API. Repository sẽ ở chế độ **Public** (GitHub Pages trên tài khoản miễn phí bắt buộc Public), ai cũng đọc được.

## 1b. Đăng nhập GitHub trên máy (một lần)

GitHub không nhận mật khẩu tài khoản khi đẩy code. Kiểm tra `gh auth status`:
- Chưa có `gh`: Mac `brew install gh` (chưa có Homebrew thì tải tại https://cli.github.com), Windows `winget install --id GitHub.cli`. Mở lại Terminal sau khi cài.
- Chưa đăng nhập: hướng dẫn người dùng mở **một cửa sổ Terminal mới** (lệnh tương tác, không chạy được trong Claude Code), chạy `gh auth login`, chọn GitHub.com → HTTPS → Yes (dùng cho Git) → Login with a web browser. Khi hiện mã dạng XXXX-XXXX: nhấn Enter để mở trình duyệt, dán mã, bấm cho phép.
- Vừa cài `gh` xong thì phải đóng và mở lại Terminal trước khi dùng.

## 2. Repository trên GitHub

- Nếu máy có `gh` và đã đăng nhập: `gh repo create <tên> --public --source=. --push`.
- Nếu không: hướng dẫn người dùng tạo repository trống trên github.com (Public, không thêm README), rồi chạy `git remote add origin <url>` và `git push -u origin main`.

## 3. Bật GitHub Pages

Hướng dẫn: repository → **Settings → Pages** → Source: **Deploy from a branch** → Branch: **main**, thư mục **/ (root)** → Save. Sau 1–2 phút website có ở `https://<tên-github>.github.io/<tên-repo>/`.

## 4. Tên miền riêng (nếu có)

- Khuyên người dùng xác minh tên miền với GitHub trước (Settings của tài khoản → Pages → Add a domain) để tránh bị chiếm tên miền.
- Tạo file `CNAME` ở thư mục gốc, nội dung đúng một dòng: `tenmien.com`. Commit và push.
- Hướng dẫn nhập tên miền ở repository → **Settings → Pages → Custom domain** → Save.
- Đưa người dùng danh sách bản ghi DNS để thêm ở nhà cung cấp tên miền:
  - 4 bản ghi `A` cho `@`: `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`
  - 1 bản ghi `CNAME` cho `www` trỏ tới `<tên-github>.github.io`
- Nhắc: DNS có thể mất tới 24 giờ. Khi GitHub báo tên miền đã đúng, tích **Enforce HTTPS** trong Settings → Pages (tuỳ chọn này có thể cần thêm vài giờ mới bật được).
- Kiểm tra lại tài liệu chính thức nếu GitHub thay đổi địa chỉ IP: https://docs.github.com/pages

## 5. Google Search Console

- Hướng dẫn thêm website tại https://search.google.com/search-console, chọn xác minh bằng thẻ HTML.
- Khi người dùng dán thẻ `<meta name="google-site-verification" ...>`, chèn vào `<head>` của trang chủ, commit, push.
- Sau khi xác minh: gửi `sitemap.xml` trong mục Sơ đồ trang web.

## 6. Thử trên điện thoại thật

Nhắc người dùng mở website trên điện thoại của họ, bấm từng nút liên hệ, mở menu, gửi link qua Zalo/Messenger để xem ảnh chia sẻ.

## Mỗi lần cập nhật sau này

Sửa → kiểm tra (`/check-site`) → commit → push. GitHub Pages tự cập nhật sau 1–2 phút.
